#! /bin/bash
for (( i=1 ; i<=100 ; i++)); do
	echo "num $i y $($i**2)) 
done
