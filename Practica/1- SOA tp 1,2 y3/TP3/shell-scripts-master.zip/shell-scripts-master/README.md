
# Explicación de Práctica 3: Shell scripting
## Introducción a los Sistemas Operativos

Scripts de ejemplo para la explicación de práctica de Shell scripting
