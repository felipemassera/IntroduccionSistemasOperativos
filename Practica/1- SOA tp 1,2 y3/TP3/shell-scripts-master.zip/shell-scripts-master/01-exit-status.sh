#!/bin/bash

# Este script retorna un exit status 3, con lo que asumiremos que su
# resultado no fue el esperado. En la documentación de nuestro script
# deberíamos describir qué posibles exit status puede tener,
# indicando qué significado tiene cada uno de los valores.

exit 3
